#!/bin/bash

echo "DB Connection Tester"
echo "====================="

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed or not in the PATH."
    echo "Please install Java and try again."
    exit 1
fi

# Create lib directory if it doesn't exist
mkdir -p lib

# Check if MySQL connector is present
if [ ! -f "lib/mysql-connector-java-8.0.33.jar" ]; then
    echo "Downloading MySQL Connector..."
    if command -v curl &> /dev/null; then
        curl -L "https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar" -o "lib/mysql-connector-java-8.0.33.jar"
    elif command -v wget &> /dev/null; then
        wget "https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar" -O "lib/mysql-connector-java-8.0.33.jar"
    else
        echo "Failed to download MySQL connector. Neither curl nor wget is available."
        echo "Please download it manually and place it in the lib directory."
        exit 1
    fi
    
    if [ $? -ne 0 ]; then
        echo "Failed to download MySQL connector."
        echo "Please download it manually and place it in the lib directory."
        exit 1
    fi
fi

# Create bin directory if it doesn't exist
mkdir -p bin

# Compile the Java file
echo "Compiling Java files..."
javac -d bin -cp "lib/mysql-connector-java-8.0.33.jar" src/main/java/org/example/DBConnectionTester.java

if [ $? -ne 0 ]; then
    echo "Compilation failed."
    exit 1
fi

# Run the application
echo "Starting DB Connection Tester..."
java -cp "bin:lib/mysql-connector-java-8.0.33.jar" org.example.DBConnectionTester
