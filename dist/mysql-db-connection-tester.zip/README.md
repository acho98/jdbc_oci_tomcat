# MySQL Database Connection Tester

A simple Java application to test MySQL database connections. This application provides a graphical user interface to enter database connection details and test the connection.

## Features

- Test connections to MySQL databases (versions 5.7 to 8.x)
- Configure connection parameters:
  - Host address
  - Port
  - Database name
  - Username
  - Password
  - SSL connection option
- View detailed connection results or error messages

## Requirements

- Java 8 or higher
- MySQL server to connect to (local or remote)

## Running on Windows

1. Download and extract the application files
2. Double-click on `run_db_tester.bat`
3. The script will:
   - Check if Java is installed
   - Download the MySQL connector if needed
   - Compile the application
   - Launch the application

## Running on Linux/macOS

1. Download and extract the application files
2. Open a terminal in the application directory
3. Make the script executable (if not already): `chmod +x run_db_tester.sh`
4. Run the script: `./run_db_tester.sh`
5. The script will:
   - Check if Java is installed
   - Download the MySQL connector if needed
   - Compile the application
   - Launch the application

## Manual Compilation and Execution

If the scripts don't work for you, you can manually compile and run the application:

1. Download the MySQL Connector/J from [Maven Repository](https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar)
2. Place it in a `lib` directory
3. Compile the application:
   ```
   javac -d bin -cp "lib/mysql-connector-java-8.0.33.jar" src/main/java/org/example/DBConnectionTester.java
   ```
4. Run the application:
   - On Windows:
     ```
     java -cp "bin;lib/mysql-connector-java-8.0.33.jar" org.example.DBConnectionTester
     ```
   - On Linux/macOS:
     ```
     java -cp "bin:lib/mysql-connector-java-8.0.33.jar" org.example.DBConnectionTester
     ```

## Changing JDBC Driver Version

If you need to test with a different version of the MySQL JDBC driver:

1. Edit the script files (`run_db_tester.bat` or `run_db_tester.sh`)
2. Change the version number in the download URL and file paths
3. For MySQL 8.x versions, use: `https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/[VERSION]/mysql-connector-j-[VERSION].jar`
4. For MySQL 5.x versions, use: `https://repo1.maven.org/maven2/mysql/mysql-connector-java/[VERSION]/mysql-connector-java-[VERSION].jar`
5. Update the classpath references in the compilation and execution commands

Note: When using very old driver versions, you may need to modify the `DBConnectionTester.java` file to change the driver class name:
- For MySQL 8.x: `com.mysql.cj.jdbc.Driver`
- For MySQL 5.x: `com.mysql.jdbc.Driver`

## Troubleshooting

- **Java not found**: Make sure Java is installed and in your system PATH
- **Compilation errors**: Ensure you have the correct version of Java installed
- **Connection errors**: Check that your MySQL server is running and accessible
- **Driver not found**: Make sure the MySQL connector JAR file is in the lib directory

---

# MySQL 데이터베이스 연결 테스터 (한국어 설명)

## 테스트 방법

### Windows에서 테스트하기

1. 프로젝트 파일을 다운로드하고 압축을 풉니다
2. `run_db_tester.bat` 파일을 더블클릭합니다
3. 스크립트가 자동으로 다음 작업을 수행합니다:
   - Java가 설치되어 있는지 확인
   - 필요한 MySQL 커넥터 다운로드
   - 애플리케이션 컴파일
   - 애플리케이션 실행
4. 실행된 애플리케이션에서 데이터베이스 연결 정보를 입력하고 "Connect to MySQL" 버튼을 클릭합니다

### Mac/Linux에서 테스트하기

1. 프로젝트 파일을 다운로드하고 압축을 풉니다
2. 터미널을 열고 프로젝트 디렉토리로 이동합니다
3. 스크립트에 실행 권한을 부여합니다: `chmod +x run_db_tester.sh`
4. 스크립트를 실행합니다: `./run_db_tester.sh`
5. 스크립트가 자동으로 다음 작업을 수행합니다:
   - Java가 설치되어 있는지 확인
   - 필요한 MySQL 커넥터 다운로드
   - 애플리케이션 컴파일
   - 애플리케이션 실행
6. 실행된 애플리케이션에서 데이터베이스 연결 정보를 입력하고 "Connect to MySQL" 버튼을 클릭합니다

## JDBC 드라이버 버전 변경 방법

다른 버전의 MySQL JDBC 드라이버로 테스트하려면:

### 방법 1: 스크립트 파일 수정

1. `run_db_tester.bat`(Windows용) 또는 `run_db_tester.sh`(Mac/Linux용) 파일을 텍스트 편집기로 엽니다
2. MySQL 커넥터 버전 번호를 변경합니다:

   **Windows (run_db_tester.bat)에서**:
   ```batch
   if not exist lib\mysql-connector-java-8.0.33.jar (
       echo Downloading MySQL Connector...
       powershell -Command "(New-Object System.Net.WebClient).DownloadFile('https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar', 'lib\mysql-connector-java-8.0.33.jar')"
   ```
   
   **Mac/Linux (run_db_tester.sh)에서**:
   ```bash
   if [ ! -f "lib/mysql-connector-java-8.0.33.jar" ]; then
       echo "Downloading MySQL Connector..."
       curl -L "https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar" -o "lib/mysql-connector-java-8.0.33.jar"
   ```

3. 위 코드에서 `8.0.33` 부분을 원하는 버전으로 변경합니다
4. 다운로드 URL도 함께 변경해야 합니다:
   - MySQL 8.x 버전: `https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/[버전]/mysql-connector-j-[버전].jar`
   - MySQL 5.x 버전: `https://repo1.maven.org/maven2/mysql/mysql-connector-java/[버전]/mysql-connector-java-[버전].jar`

5. 컴파일 및 실행 명령어의 클래스패스(-cp) 옵션에서도 JAR 파일 이름을 변경해야 합니다

### 방법 2: 수동으로 JDBC 드라이버 교체

1. 원하는 버전의 MySQL JDBC 드라이버를 [Maven Repository](https://mvnrepository.com/artifact/mysql/mysql-connector-java)에서 다운로드합니다
2. 다운로드한 JAR 파일을 `lib` 디렉토리에 저장합니다
3. 스크립트 파일을 수정하거나, 수동으로 다음 명령어를 실행합니다:

   **Windows**:
   ```
   javac -d bin -cp "lib\[다운로드한-jar-파일명].jar" src\main\java\org\example\DBConnectionTester.java
   java -cp "bin;lib\[다운로드한-jar-파일명].jar" org.example.DBConnectionTester
   ```

   **Mac/Linux**:
   ```
   javac -d bin -cp "lib/[다운로드한-jar-파일명].jar" src/main/java/org/example/DBConnectionTester.java
   java -cp "bin:lib/[다운로드한-jar-파일명].jar" org.example.DBConnectionTester
   ```

### 주의사항

매우 오래된 JDBC 드라이버 버전을 사용할 경우, `DBConnectionTester.java` 파일에서 드라이버 클래스 이름을 변경해야 할 수 있습니다:

```java
// 8.x 버전용
Class.forName("com.mysql.cj.jdbc.Driver");

// 5.x 버전용으로 변경
// Class.forName("com.mysql.jdbc.Driver");
```

해당 라인을 찾아 주석 처리를 변경하여 적절한 드라이버 클래스를 사용하도록 합니다.
