package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * A standalone Java application for testing MySQL database connections.
 * This can be run directly with: java -cp "path/to/mysql-connector.jar:." org.example.DBConnectionTester
 */
public class DBConnectionTester {
    private JFrame frame;
    private JTextField hostField;
    private JTextField portField;
    private JTextField databaseField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox sslCheckBox;
    private JTextArea resultArea;
    
    public static void main(String[] args) {
        // Set look and feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Create and show GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            new DBConnectionTester().createAndShowGUI();
        });
    }
    
    private void createAndShowGUI() {
        // Create the main frame
        frame = new JFrame("Test DB Connection");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.setLocationRelativeTo(null);
        
        // Create the main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Create form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Database Connection Parameters"),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Host field
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Database Host:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        hostField = new JTextField("localhost", 20);
        formPanel.add(hostField, gbc);
        
        // Port field
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Port:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        portField = new JTextField("3306", 20);
        formPanel.add(portField, gbc);
        
        // Database field
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Database Name:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        databaseField = new JTextField("mysql", 20);
        formPanel.add(databaseField, gbc);
        
        // Username field
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Username:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        usernameField = new JTextField("root", 20);
        formPanel.add(usernameField, gbc);
        
        // Password field
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Password:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        passwordField = new JPasswordField(20);
        formPanel.add(passwordField, gbc);
        
        // SSL checkbox
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        sslCheckBox = new JCheckBox("Use SSL Connection");
        formPanel.add(sslCheckBox, gbc);
        
        // Connect button
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton connectButton = new JButton("Connect to MySQL");
        connectButton.addActionListener(e -> testConnection());
        formPanel.add(connectButton, gbc);
        
        // Result area
        resultArea = new JTextArea(10, 40);
        resultArea.setEditable(false);
        resultArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Connection Results"),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        
        // Add components to main panel
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Add main panel to frame
        frame.getContentPane().add(mainPanel);
        
        // Display the frame
        frame.setVisible(true);
    }
    
    private void testConnection() {
        // Get connection parameters from form
        String host = hostField.getText().trim();
        String port = portField.getText().trim();
        String database = databaseField.getText().trim();
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        boolean useSSL = sslCheckBox.isSelected();
        
        // Clear previous results
        resultArea.setText("Attempting to connect to MySQL database:\n");
        resultArea.append("Host: " + host + "\n");
        resultArea.append("Port: " + port + "\n");
        resultArea.append("Database: " + database + "\n");
        resultArea.append("Username: " + username + "\n");
        resultArea.append("Use SSL: " + useSSL + "\n\n");
        
        // Build connection URL
        String url = "jdbc:mysql://" + host + ":" + port + "/" + database;
        
        // Create a new thread for the database connection to avoid freezing the UI
        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                StringBuilder result = new StringBuilder();
                
                try {
                    // Load the MySQL JDBC driver
                    // For MySQL 8.x use: com.mysql.cj.jdbc.Driver
                    // For MySQL 5.x use: com.mysql.jdbc.Driver
                    String driverClass = "com.mysql.cj.jdbc.Driver";
                    // Uncomment the line below and comment the line above to use MySQL 5.x driver
                    // String driverClass = "com.mysql.jdbc.Driver";
                    
                    Class.forName(driverClass);
                    
                    // Set connection properties
                    Properties properties = new Properties();
                    properties.setProperty("user", username);
                    properties.setProperty("password", password);
                    properties.setProperty("useSSL", String.valueOf(useSSL));
                    properties.setProperty("allowPublicKeyRetrieval", "true");
                    
                    // Attempt to establish a connection
                    try (Connection conn = DriverManager.getConnection(url, properties)) {
                        result.append("Connection successful!\n");
                        result.append("Connected to: ").append(conn.getMetaData().getDatabaseProductName())
                              .append(" ").append(conn.getMetaData().getDatabaseProductVersion());
                    }
                } catch (ClassNotFoundException e) {
                    result.append("Error: MySQL JDBC driver not found.\n");
                    result.append("Error details: ").append(e.getMessage());
                } catch (SQLException e) {
                    result.append("Connection failed!\n");
                    result.append("Error code: ").append(e.getErrorCode()).append("\n");
                    result.append("SQL State: ").append(e.getSQLState()).append("\n");
                    result.append("Error message: ").append(e.getMessage());
                }
                
                return result.toString();
            }
            
            @Override
            protected void done() {
                try {
                    String result = get();
                    resultArea.append(result);
                } catch (Exception e) {
                    resultArea.append("An unexpected error occurred: " + e.getMessage());
                }
            }
        }.execute();
    }
}
